export function PatientAppointmentsView() {
  return (
    <section className="max-w-4xl mx-auto px-6 md:px-12 py-16">
      <p className="font-mono text-xs uppercase tracking-wide text-[var(--coral)] mb-3">
        Appointments
      </p>
      <h1 className="font-display text-2xl text-[var(--teal-900)] mb-3">
        Your upcoming appointments
      </h1>
      <p className="text-[var(--ink-soft)] max-w-md">
        Booked serials and their live estimated time will show here, backed by
        Appointment + AppointmentQueue. Booking a new one against a
        DoctorSchedule comes next.
      </p>
    </section>
  );
}
