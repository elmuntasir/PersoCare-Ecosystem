"use client";

import { useRouter } from "next/navigation";
import { createClient } from "@/utils/supabase/client";
import type { DashboardUser } from "@/lib/get-current-dashboard-user";

export function DashboardTopbar({ user }: { user: DashboardUser }) {
  const router = useRouter();

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <header className="flex items-center justify-end md:justify-between px-6 md:px-10 py-5 border-b border-[var(--sage-200)]">
      <span className="hidden md:inline text-sm text-[var(--ink-soft)]">
        {user.name} ·{" "}
        <span className="font-mono uppercase text-xs">{user.primaryRole.label}</span>
      </span>
      <button
        onClick={handleLogout}
        className="text-sm font-medium px-4 py-2 rounded-full border border-[var(--sage-200)] text-[var(--teal-900)] hover:bg-[var(--sage-200)] transition-colors"
      >
        Log out
      </button>
    </header>
  );
}
