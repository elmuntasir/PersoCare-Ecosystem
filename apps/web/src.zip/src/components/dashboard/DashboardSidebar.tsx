"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import type { DashboardRole } from "@/lib/get-current-dashboard-user";

type NavItem = {
  href: string;
  label: string;
  /** Omit to show for everyone. */
  visibleFor?: (role: DashboardRole) => boolean;
};

const NAV_ITEMS: NavItem[] = [
  { href: "/dashboard", label: "Overview" },
  { href: "/dashboard/appointments", label: "Appointments" },
  { href: "/dashboard/records", label: "Health Records" },
  {
    href: "/dashboard/queue",
    label: "Today's Queue",
    visibleFor: (role) => role.kind === "profession",
  },
  {
    href: "/dashboard/organization",
    label: "Organization",
    visibleFor: (role) => role.kind === "org_role" || role.kind === "platform_owner",
  },
  { href: "/dashboard/profile", label: "Profile" },
];

export function DashboardSidebar({ role }: { role: DashboardRole }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const items = NAV_ITEMS.filter((item) => !item.visibleFor || item.visibleFor(role));

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(true)}
        className="md:hidden fixed top-4 left-4 z-30 w-10 h-10 flex items-center justify-center rounded-lg bg-white border border-[var(--sage-200)]"
        aria-label="Open menu"
      >
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
          <path d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>

      {mobileOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/30 z-30"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={`
          fixed md:static inset-y-0 left-0 z-40 w-64 shrink-0
          bg-white border-r border-[var(--sage-200)] flex flex-col
          transition-transform duration-200
          ${mobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
        `}
      >
        <div className="px-6 py-6">
          <span className="font-display text-lg text-[var(--teal-900)]">PersoCare</span>
        </div>

        <nav className="flex-1 px-3 space-y-1">
          {items.map((item) => {
            const active =
              item.href === "/dashboard"
                ? pathname === "/dashboard"
                : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className={`block px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  active
                    ? "bg-[var(--sage-200)] text-[var(--teal-900)]"
                    : "text-[var(--ink-soft)] hover:bg-[var(--sage-200)]/60"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </aside>
    </>
  );
}
