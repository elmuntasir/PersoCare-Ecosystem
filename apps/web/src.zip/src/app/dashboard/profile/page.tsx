import { requireDashboardUser } from "@/lib/get-current-dashboard-user";

export default async function ProfilePage() {
  const user = await requireDashboardUser();

  return (
    <section className="max-w-4xl mx-auto px-6 md:px-12 py-16">
      <p className="font-mono text-xs uppercase tracking-wide text-[var(--coral)] mb-3">
        Profile
      </p>
      <h1 className="font-display text-2xl text-[var(--teal-900)] mb-3">{user.name}</h1>
      <p className="text-[var(--ink-soft)]">{user.email}</p>
      <p className="mt-6 text-[var(--ink-soft)] max-w-md text-sm">
        Editable profile fields, plus the entry point to apply for a verified
        profession (UserProfession + ProfessionDocument upload), will live
        here.
      </p>
    </section>
  );
}
