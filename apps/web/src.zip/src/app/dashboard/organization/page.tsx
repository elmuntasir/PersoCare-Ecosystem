import { requireRole } from "@/lib/get-current-dashboard-user";

export default async function OrganizationPage() {
  await requireRole(["org_role", "platform_owner"]);

  return (
    <section className="max-w-4xl mx-auto px-6 md:px-12 py-16">
      <p className="font-mono text-xs uppercase tracking-wide text-[var(--coral)] mb-3">
        Organization
      </p>
      <h1 className="font-display text-2xl text-[var(--teal-900)] mb-3">
        Members &amp; roles
      </h1>
      <p className="text-[var(--ink-soft)] max-w-md">
        OrganizationMembership management, Role/Permission assignment, and
        profession-verification review queue will live here.
      </p>
    </section>
  );
}
