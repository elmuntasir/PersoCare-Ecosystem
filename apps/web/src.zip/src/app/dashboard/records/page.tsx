import { requireDashboardUser } from "@/lib/get-current-dashboard-user";

export default async function RecordsPage() {
  await requireDashboardUser();

  return (
    <section className="max-w-4xl mx-auto px-6 md:px-12 py-16">
      <p className="font-mono text-xs uppercase tracking-wide text-[var(--coral)] mb-3">
        Health Records
      </p>
      <h1 className="font-display text-2xl text-[var(--teal-900)] mb-3">
        Your health history
      </h1>
      <p className="text-[var(--ink-soft)] max-w-md">
        ClinicalMeasurement history, HealthHistoryEvent timeline, vaccinations,
        and PatientProfile details will render here.
      </p>
    </section>
  );
}
