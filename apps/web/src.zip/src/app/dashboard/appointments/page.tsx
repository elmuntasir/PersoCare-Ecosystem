import { requireDashboardUser } from "@/lib/get-current-dashboard-user";
import { PatientAppointmentsView } from "@/components/dashboard/appointments/PatientAppointmentsView";
import { DoctorQueueView } from "@/components/dashboard/appointments/DoctorQueueView";
import { OrgAppointmentsView } from "@/components/dashboard/appointments/OrgAppointmentsView";

export default async function AppointmentsPage() {
  const user = await requireDashboardUser();

  switch (user.primaryRole.kind) {
    case "profession":
      return <DoctorQueueView />;
    case "org_role":
    case "platform_owner":
      return <OrgAppointmentsView />;
    case "patient":
      return <PatientAppointmentsView />;
  }
}
