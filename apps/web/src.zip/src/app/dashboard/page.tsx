import { requireDashboardUser } from "@/lib/get-current-dashboard-user";
import { PulseLine } from "@/components/PulseLine";
import type { DashboardRole } from "@/lib/get-current-dashboard-user";

function greeting(role: DashboardRole): { title: string; body: string } {
  switch (role.kind) {
    case "platform_owner":
      return {
        title: "Platform overview",
        body: "Organizations, profession verifications, and platform-wide activity will appear here.",
      };
    case "org_role":
      return {
        title: `${role.organizationName} overview`,
        body: "Members, roles, and appointment activity for your organization will appear here.",
      };
    case "profession":
      return {
        title: "Today's queue",
        body: "Your scheduled patients and prescribe/skip/cancel actions will appear here.",
      };
    case "patient":
      return {
        title: "Your health, in one place",
        body: "Appointments, prescriptions, and your history will appear here.",
      };
  }
}

export default async function DashboardOverviewPage() {
  // Same request as the layout's call — cache() means this is free, not a
  // second round trip to Supabase/Postgres.
  const user = await requireDashboardUser();
  const { title, body } = greeting(user.primaryRole);

  return (
    <section className="max-w-4xl mx-auto px-6 md:px-12 py-16 text-center">
      <p className="font-mono text-xs uppercase tracking-wide text-[var(--coral)] mb-3">
        Signed in
      </p>
      <h1 className="font-display text-3xl text-[var(--teal-900)] mb-3">{title}</h1>
      <p className="text-[var(--ink-soft)] max-w-md mx-auto">{body}</p>

      <div className="mt-12 h-16 opacity-60">
        <PulseLine className="w-full h-full" />
      </div>
    </section>
  );
}
