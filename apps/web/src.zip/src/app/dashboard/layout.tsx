import { requireDashboardUser } from "@/lib/get-current-dashboard-user";
import { DashboardSidebar } from "@/components/dashboard/DashboardSidebar";
import { DashboardTopbar } from "@/components/dashboard/DashboardTopbar";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Resolved once per request here; any page under /dashboard can call
  // requireDashboardUser() again for its own data needs at zero extra cost.
  const user = await requireDashboardUser();

  return (
    <div className="min-h-screen flex bg-[var(--paper)]">
      <DashboardSidebar role={user.primaryRole} />
      <div className="flex-1 flex flex-col min-w-0">
        <DashboardTopbar user={user} />
        <main className="flex-1">{children}</main>
      </div>
    </div>
  );
}
