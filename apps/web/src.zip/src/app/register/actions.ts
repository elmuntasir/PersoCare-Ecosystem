"use server";

import { prisma } from "@/lib/prisma";

export type CreatePatientAccountInput = {
  authId: string;
  name: string;
  email: string;
  phone: string;
  dob: string; // yyyy-mm-dd from <input type="date">
  gender: string;
};

export type CreatePatientAccountResult =
  | { ok: true }
  | { ok: false; error: string };

/**
 * Creates the application-level User row (this project's own identity
 * record) and links it to the Supabase Auth user via `authId`.
 *
 * Supabase Auth already created the login credential — this only stores the
 * profile fields our schema needs (name, phone, dob, gender). Every account
 * is created as a plain patient; professional roles (doctor, etc.) are
 * requested afterward via the profession-verification flow, never chosen at
 * signup.
 */
export async function createPatientAccount(
  input: CreatePatientAccountInput
): Promise<CreatePatientAccountResult> {
  const { authId, name, email, phone, dob, gender } = input;

  if (!authId || !name.trim() || !email.trim()) {
    return { ok: false, error: "Missing required fields." };
  }

  try {
    await prisma.user.create({
      data: {
        authId,
        name: name.trim(),
        email: email.trim().toLowerCase(),
        phone: phone.trim() || null,
        dob: dob ? new Date(dob) : null,
        gender: gender || null,
      },
    });
    return { ok: true };
  } catch (err: unknown) {
    // Prisma unique constraint violation
    const code = (err as { code?: string })?.code;
    if (code === "P2002") {
      return {
        ok: false,
        error: "An account with this email already exists.",
      };
    }
    console.error("createPatientAccount failed:", err);
    return { ok: false, error: "Couldn't finish creating your profile." };
  }
}
