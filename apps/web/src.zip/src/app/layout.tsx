import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PersoCare",
  description: "One platform for your care — hospitals, clinics, and pharmacies, connected.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
