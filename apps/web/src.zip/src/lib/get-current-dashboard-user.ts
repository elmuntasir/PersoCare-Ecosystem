import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { createClient } from "@/utils/supabase/server";
import { prisma } from "@/lib/prisma";

export type DashboardRole =
  | { kind: "platform_owner"; label: "Platform Owner" }
  | { kind: "profession"; label: string } // e.g. "Doctor", verified UserProfession
  | { kind: "org_role"; label: string; organizationName: string } // active OrganizationMembership
  | { kind: "patient"; label: "Patient" }; // default, everyone has this

export type DashboardUser = {
  id: string;
  authId: string;
  name: string;
  email: string;
  /**
   * The single role shown in the topbar/sidebar. A user can actually hold
   * several (patient + verified doctor + org membership) — this just picks
   * the most privileged one for display. Don't use this for authorization;
   * every real permission check happens server-side against the underlying
   * tables (professions/memberships), not this label.
   */
  primaryRole: DashboardRole;
};

/**
 * Wrapped in React's cache() so calling this from both dashboard/layout.tsx
 * and a page.tsx in the same request hits the DB once, not twice — Next
 * doesn't dedupe Prisma calls the way it dedupes fetch().
 */
const getDashboardUserOrNull = cache(async (): Promise<DashboardUser | null> => {
  const cookieStore = await cookies();
  const supabase = createClient(cookieStore);
  const {
    data: { user: authUser },
  } = await supabase.auth.getUser();

  if (!authUser) {
    return null;
  }

  const user = await prisma.user.findUnique({
    where: { authId: authUser.id },
    include: {
      platformOwner: true,
      professions: {
        where: { status: "VERIFIED" },
        include: { professionType: true },
      },
      memberships: {
        where: { status: "ACTIVE" },
        include: { role: true, organization: true },
      },
    },
  });

  // Auth account exists in Supabase but the profile row is missing —
  // shouldn't happen if register/actions.ts ran, but don't let it 500.
  if (!user) {
    return null;
  }

  let primaryRole: DashboardRole = { kind: "patient", label: "Patient" };

  if (user.memberships[0]) {
    const m = user.memberships[0];
    primaryRole = {
      kind: "org_role",
      label: m.role.name,
      organizationName: m.organization.name,
    };
  }
  if (user.professions[0]) {
    primaryRole = {
      kind: "profession",
      label: user.professions[0].professionType.name,
    };
  }
  if (user.platformOwner) {
    primaryRole = { kind: "platform_owner", label: "Platform Owner" };
  }

  return {
    id: user.id,
    authId: authUser.id,
    name: user.name,
    email: user.email,
    primaryRole,
  };
});

/**
 * Fetches the current dashboard user or redirects to /login. Call this at
 * the top of the dashboard layout AND, if a page needs the data too, again
 * in that page — the cache() wrapper above means the second call is free
 * (same request, same result) rather than a second round trip.
 */
export async function requireDashboardUser(): Promise<DashboardUser> {
  const user = await getDashboardUserOrNull();
  if (!user) {
    redirect("/login");
  }
  return user;
}

/**
 * Use inside a route segment that only some roles should reach (e.g.
 * /dashboard/queue for professionals, /dashboard/organization for org
 * roles). Hiding the sidebar link is UX only — this is the actual
 * authorization check. Redirects back to the overview page rather than
 * a raw 403 so a stale bookmark just quietly lands somewhere valid.
 */
export async function requireRole(
  allowed: DashboardRole["kind"][]
): Promise<DashboardUser> {
  const user = await requireDashboardUser();
  if (!allowed.includes(user.primaryRole.kind)) {
    redirect("/dashboard");
  }
  return user;
}
